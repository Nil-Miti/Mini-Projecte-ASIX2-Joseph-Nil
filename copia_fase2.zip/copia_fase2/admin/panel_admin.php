<?php
session_start();

// Verificar si el usuario está autenticado y tiene permisos
if (!(isset($_SESSION['id_usuario']) && ($_SESSION['nom'] == 'joseph' || $_SESSION['nom'] == 'nil'))) {
    // Redirigir a la página de inicio de sesión o mostrar un mensaje de error
    header("Location: /auth/login.php");
    exit();
}
echo $_SESSION['nom'];
// Conexión a la base de datos (modificar según tus credenciales)
$servername = "localhost";
$username = "admin";
$password = "1234";
$dbname = "server";

$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar la conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}
$usuario = $_SESSION['nom'];
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_id = $_POST['user_id'];
    if (isset($_POST['accept'])) {
        $estado = 'autorizado';
    } elseif (isset($_POST['reject'])) {
        $estado = 'no_autorizado';
    }
$estado = "UPDATE usuario SET estado = '$estado' WHERE ID_USER = $user_id";
if ($conn->query($estado) === TRUE) {
        echo "Estado actualizado exitosamente";
    } else {
        echo "Error al actualizar el estado: " . $conn->error;
    }
}
$sql = "SELECT ID_USER, USER_NAME, email FROM usuario WHERE estado = 'espera'";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel de Administrador</title>
</head>
<body>
    <h2>Panel de Administrador</h2>
    <table>
        <tr>
            <th>Nombre de Usuario</th>
            <th>Correo Electrónico</th>
            <th>Asignar Departamento</th>
            <th>Acción</th>
        </tr>
        <?php
        // Paso 3: Mostrar los usuarios en el panel de administrador
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $row["USER_NAME"] . "</td>";
                echo "<td>" . $row["email"] . "</td>";
                echo "<td><!-- Aquí puedes crear un select para elegir el departamento --></td>";
                echo "<td>
                        <form action='panel_admin.php' method='post'>
                            <input type='hidden' name='user_id' value='" . $row["ID_USER"] . "'>
                            <input type='submit' name='accept' value='Aceptar'>
                            <input type='submit' name='reject' value='Rechazar'>
                        </form>
                      </td>";
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='4'>No hay usuarios en espera</td></tr>";
        }
        ?>
    </table>
</body>
</html>

<?php
$conn->close();
?>
