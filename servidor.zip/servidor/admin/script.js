$(document).ready(function() {
   $('#section1').DataTable();
});

$(document).ready(function() {
   $('#section2').DataTable();
});

$(document).ready(function() {
   $('#section3').DataTable();
});
